import "@fontsource-variable/quicksand";
import "sanitize.css";
import "sanitize.css/assets.css";
import "sanitize.css/forms.css";
import "sanitize.css/reduce-motion.css";

import "./base.css";
import "./variables.css";
